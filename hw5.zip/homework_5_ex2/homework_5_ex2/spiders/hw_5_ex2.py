import scrapy


class Hw5Ex2Spider(scrapy.Spider):
    name = 'hw_5_ex2'
    allowed_domains = ['imdb.com']
    start_urls = ['http://imdb.com/chart/top']

    def parse(self, response):
    	for i in response.css('tr')[1:-2]:
    		yield{
    		'Movie_Rank': i.css('td.titleColumn::text').re('[0-9]+')[0],
            'Title': i.css('td.titleColumn a::text').extract_first(),
            'URL': 'http://imdb.com' + str(i.css("td.titleColumn a::attr(href)").extract_first()),
            'Release_Year': i.css("span.secondaryInfo::text").extract_first(),
            'Rating': i.css('td strong::text').extract_first()  
    		}
        
        average =[]
        for f in response.css('tr')[1:-2]:
            rating=f.css('td strong::text').extract_first()
        a=float(rating)
        average.append(a)
        avg=sum(average)/len(average)
        yield{
        "Average is":avg
        }