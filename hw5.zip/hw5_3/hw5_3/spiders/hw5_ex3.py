# -*- coding: utf-8 -*-
import scrapy
import json


class Hw5Ex3Spider(scrapy.Spider):
    name = 'hw5_ex3'
    allowed_domains = ['http://www.imdb.com/chart/top']
    start_urls = ['http://http://www.imdb.com/chart/top/']

    with open ('C:\Data_scraping\homework_5_ex2\homework_5_ex2\ex5.2.json') as f:
    	r = f.read()
    	url = json.loads(r)
    	for i in range(10):
    		start_urls.append(url[i]['URL'])

    def parse(self, response):
        yield{
        "Movie": response.xpath('//*[contains(@class, "title_wrapper")]/h1/text()').extract_first(),
        "director": response.xpath('//*[contains(@class, "credit_summary_item")]/span/a/span/text()').extract_first()
        }
