# -*- coding: utf-8 -*-
import scrapy


class Homework5Ex1Spider(scrapy.Spider):
    name = 'homework_5_ex1'
    allowed_domains = ['stackoverflow.com']
    start_urls = ['https://stackoverflow.com/questions/tagged/python/?page=1&sort=newest&pageSize=50',
    'https://stackoverflow.com/questions/tagged/machine-learning?page=2&sort=newest&pagesize=50',
    'https://stackoverflow.com/questions/tagged/machine-learning?page=3&sort=newest&pagesize=50']

    def parse(self, response):
        for i in response.css('div.summary'):
        	yield{
        	"Question": i.css('h3 a.question-hyperlink::text').extract_first(),
        	"URL": "https://stackoverflow.com/questions" + str(i.css('a.question-hyperlink::attr(href)').extract_first())
}

